package com.example.quizz_pokemon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
